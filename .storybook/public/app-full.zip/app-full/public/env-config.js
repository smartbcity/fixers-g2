window._env_ = {
  //the environnement variables
};
