import { AppRouter } from "./routes";

const App = () => {

  return (
      <AppRouter />
  );
}

export default App;
