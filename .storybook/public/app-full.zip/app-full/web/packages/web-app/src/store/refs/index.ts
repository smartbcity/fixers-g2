import { actions } from "./refs.actions";
import { selectors } from "./refs.selectors";

export const refs = {
  actions: actions,
  selectors: selectors,
};
