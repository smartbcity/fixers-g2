window._env_ = {
  i2OrgUrl: undefined, //set this if you want to have the organization module appearing in your app
  i2UserUrl: undefined, //set this if you want to have the organization module appearing in your app
};
