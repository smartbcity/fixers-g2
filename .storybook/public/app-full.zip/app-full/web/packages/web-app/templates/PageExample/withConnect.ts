import { connect } from "react-redux";
import { State } from "store";

const mapStateToProps = (state: State) => ({});

const mapDispatchToProps = {};

export default connect(mapStateToProps, mapDispatchToProps);
