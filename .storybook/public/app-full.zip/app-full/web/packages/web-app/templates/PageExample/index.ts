import { Example } from "./Example";
import withConnect from "./withConnect";

export default withConnect(Example);
