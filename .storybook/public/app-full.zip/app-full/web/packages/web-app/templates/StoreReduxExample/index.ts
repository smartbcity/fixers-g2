import { actions } from "./example.actions";
import { selectors } from "./example.selectors";

export const example = {
  actions: actions,
  selectors: selectors,
};
