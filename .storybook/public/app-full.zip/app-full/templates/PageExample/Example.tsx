import React from "react";
import { useTranslation } from "react-i18next";

interface ExampleProps {}

export const Example = (props: ExampleProps) => {
  const {} = props;
  const { t } = useTranslation();
  return <div></div>;
};
